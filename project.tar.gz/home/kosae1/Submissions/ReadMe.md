
touch Submissions 
mv The\ Hunger\ Games.txt /home/kosae1/Submissions
cp The\ Hunger\ Games.txt My\ Hunger\ Games.txt
chmod g-rw, o-x
sed -i 's/Peeta \Mellark/Kofi/g' My\ Hunger\ Games.txt
sed -i 's/Peeta/Kofi/g' My\ Hunger\ Games.txt





